<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Email</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>


    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title></title>

        <style type="text/css">
          @media screen and (max-width: 600px) {
            .social__media-holder img {
              width: 25px;
            }

            .row__padding img {
              width: 170px;
            }
          }
        </style>
      </head>

      <body style="margin: 0; padding: 0; font-family: 'Roboto'">
        <center>
          <table
            class="email__verification"
            style="
              border: none;
              border-collapse: inherit;
              border-spacing: 0;
              border-color: inherit;
              vertical-align: inherit;
              font-weight: inherit;
              width: 600px;
            "
          >
            <tr
              style="
                border: none;
                border-collapse: inherit;
                border-spacing: 0;
                border-color: inherit;
                vertical-align: inherit;
                font-weight: inherit;
                width: 600px;
              "
            >
              <td
                align="center"
                valign="top"
                style="
                  border: none;
                  border-collapse: inherit;
                  border-spacing: 0;
                  border-color: inherit;
                  vertical-align: inherit;
                  font-weight: inherit;
                  width: 600px;
                  padding: 0;
                "
              >
                <!-- Begin Logo partial -->
                <table
                  class="wrapper"
                  style="
                    border: none;
                    border-collapse: inherit;
                    border-spacing: 0;
                    border-color: inherit;
                    vertical-align: inherit;
                    font-weight: inherit;
                    width: 600px;
                    background-color: #d4d4d425;
                  "
                >
                  <tr
                    style="
                      border: none;
                      border-collapse: inherit;
                      border-spacing: 0;
                      border-color: inherit;
                      vertical-align: inherit;
                      font-weight: inherit;
                      width: 600px;
                    "
                  >
                    <td
                      align="center"
                      valign="top"
                      style="
                        border: none;
                        border-collapse: inherit;
                        border-spacing: 0;
                        border-color: inherit;
                        vertical-align: inherit;
                        font-weight: inherit;
                        width: 600px;
                        padding: 0;
                      "
                    >
                      <table
                        class="container"
                        style="
                          border: none;
                          border-collapse: inherit;
                          border-spacing: 0;
                          border-color: inherit;
                          vertical-align: inherit;
                          font-weight: inherit;
                          width: 600px;
                        "
                      >
                        <tr
                          style="
                            border: none;
                            border-collapse: inherit;
                            border-spacing: 0;
                            border-color: inherit;
                            vertical-align: inherit;
                            font-weight: inherit;
                            width: 600px;
                          "
                        >
                          <td
                            class="row__padding"
                            align="center"
                            style="
                              border: none;
                              border-collapse: inherit;
                              border-spacing: 0;
                              border-color: inherit;
                              vertical-align: inherit;
                              font-weight: inherit;
                              width: 600px;
                              padding: 0;
                            "
                          >
                            <img
                              height="auto"
                              width="185"
                              style="
                                border: 0;
                                opacity: 1;
                                border-radius: 0px;
                                padding: 20px;
                              "
                              src="{{asset('setting/'. $logo)}}"
                            />
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>
                <!-- End Logo partial -->
              </td>
            </tr>
            <tr
              style="
                border: none;
                border-collapse: inherit;
                border-spacing: 0;
                border-color: inherit;
                vertical-align: inherit;
                font-weight: inherit;
                width: 600px;
              "
            >
              <td
                style="
                  border: none;
                  border-collapse: inherit;
                  border-spacing: 0;
                  border-color: inherit;
                  vertical-align: inherit;
                  font-weight: inherit;
                  width: 600px;
                  padding: 0;
                  background-color: orange;
                  color: #fff;
                  padding: 40px 0;
                "
              >
                <!-- <img src="img/verify.JPG" alt="" width="600" style="border:0;"> -->
                <center>
                  <img
                    src="https://cdn-icons-png.flaticon.com/512/481/481659.png"
                    alt=""
                    width="50"
                    style="filter: brightness(0) invert(1)"
                  />
                  <h4>Thanks For Sending Message</h4>
                  <!-- <h2>Verify Your E-mail Address</h2> -->
                </center>
              </td>
            </tr>
            <tr
              style="
                border: none;
                border-collapse: inherit;
                border-spacing: 0;
                border-color: inherit;
                vertical-align: inherit;
                font-weight: inherit;
                width: 600px;
              "
            >
              <td
                style="
                  border: none;
                  border-collapse: inherit;
                  border-spacing: 0;
                  border-color: inherit;
                  vertical-align: inherit;
                  font-weight: inherit;
                  width: 600px;
                  padding: 0;
                "
              >
                <table
                  width="100%"
                  style="
                    border: none;
                    border-collapse: inherit;
                    border-spacing: 0;
                    border-color: inherit;
                    vertical-align: inherit;
                    font-weight: inherit;
                    width: 600px;
                    text-align: center;
                    background-color: #d4d4d425;
                  "
                >
                  <center>
                    <tr
                      style="
                        border: none;
                        border-collapse: inherit;
                        border-spacing: 0;
                        border-color: inherit;
                        vertical-align: inherit;
                        font-weight: inherit;
                        width: 600px;
                      "
                    >
                      <td
                        style="
                          border: none;
                          border-collapse: inherit;
                          border-spacing: 0;
                          border-color: inherit;
                          vertical-align: inherit;
                          font-weight: inherit;
                          width: 600px;
                          padding: 0;
                        "
                      >
                        <h2 style="font-weight: 300; margin-bottom: 0">Hi,{{$student_name}}</h2>
                      </td>
                    </tr>
                    <tr
                      style="
                        border: none;
                        border-collapse: inherit;
                        border-spacing: 0;
                        border-color: inherit;
                        vertical-align: inherit;
                        font-weight: inherit;
                        width: 600px;
                      "
                    >
                      <td
                        class="content__wrapper"
                        style="
                          border: none;
                          border-collapse: inherit;
                          border-spacing: 0;
                          border-color: inherit;
                          vertical-align: inherit;
                          font-weight: inherit;
                          width: 600px;
                          padding: 0;
                          padding: 0 50px;
                        "
                      >
                        <p style="font-size: 16px">
                          {{ strip_tags($email_message)}}
                        </p>
                      </td>
                    </tr>
                  </center>
                </table>
              </td>
            </tr>
            <tr
              style="
                border: none;
                border-collapse: inherit;
                border-spacing: 0;
                border-color: inherit;
                vertical-align: inherit;
                font-weight: inherit;
                width: 600px;
              "
            >
              <td
                style="
                  border: none;
                  border-collapse: inherit;
                  border-spacing: 0;
                  border-color: inherit;
                  vertical-align: inherit;
                  font-weight: inherit;
                  width: 600px;
                  padding: 0;
                "
              >
                <table
                  class="verify__button-main"
                  style="
                    border: none;
                    border-collapse: inherit;
                    border-spacing: 0;
                    border-color: inherit;
                    vertical-align: inherit;
                    font-weight: inherit;
                    background-color: #d4d4d425;
                    width: 600px;
                  "
                >
                  <tr
                    style="
                      border: none;
                      border-collapse: inherit;
                      border-spacing: 0;
                      border-color: inherit;
                      vertical-align: inherit;
                      font-weight: inherit;
                      width: 600px;
                    "
                  >
                    <td
                      style="
                        border: none;
                        border-collapse: inherit;
                        border-spacing: 0;
                        border-color: inherit;
                        vertical-align: inherit;
                        font-weight: inherit;
                        width: 600px;
                        padding: 0;
                      "
                    ></td>
                  </tr>
                </table>
              </td>
            </tr>

            <tr
              style="
                border: none;
                border-collapse: inherit;
                border-spacing: 0;
                border-color: inherit;
                vertical-align: inherit;
                font-weight: inherit;
                width: 600px;
              "
            >
              <td
                style="
                  border: none;
                  border-collapse: inherit;
                  border-spacing: 0;
                  border-color: inherit;
                  vertical-align: inherit;
                  font-weight: inherit;
                  width: 600px;
                  padding: 0;
                "
              >
                <table
                  class="company__name"
                  style="
                    border: none;
                    border-collapse: inherit;
                    border-spacing: 0;
                    border-color: inherit;
                    vertical-align: inherit;
                    font-weight: inherit;
                    width: 600px;
                    background-color: #d4d4d425;
                    padding: 50px 0;
                    text-align: center;
                  "
                >
                  <tr
                    style="
                      border: none;
                      border-collapse: inherit;
                      border-spacing: 0;
                      border-color: inherit;
                      vertical-align: inherit;
                      font-weight: inherit;
                      margin: 50px 0;
                      width: 600px;
                    "
                  >
                    <td
                      style="
                        border: none;
                        border-collapse: inherit;
                        border-spacing: 0;
                        border-color: inherit;
                        vertical-align: inherit;
                        font-weight: inherit;
                        width: 600px;
                        padding: 0;
                      "
                    >
                      <p style="margin: 10px 0 5px 0">Thanks,</p>
                    </td>
                  </tr>
                  <tr
                    style="
                      border: none;
                      border-collapse: inherit;
                      border-spacing: 0;
                      border-color: inherit;
                      vertical-align: inherit;
                      margin: 50px 0;
                      font-weight: inherit;
                      width: 600px;
                    "
                  >
                    <td
                      style="
                        border: none;
                        border-collapse: inherit;
                        border-spacing: 0;
                        border-color: inherit;
                        vertical-align: inherit;
                        font-weight: inherit;
                        width: 600px;
                        padding: 0;
                      "
                    >
                      <p style="margin: 0 0 15px 0">{{$school_name}}</p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <tr
              class="social__media-holder"
              style="
                border: none;
                border-collapse: inherit;
                border-spacing: 0;
                border-color: inherit;
                vertical-align: inherit;
                font-weight: inherit;
                width: 600px;
                background-color: #e5eaf5;
              "
            >
              <td
                style="
                  border: none;
                  border-collapse: inherit;
                  border-spacing: 0;
                  border-color: inherit;
                  vertical-align: inherit;
                  font-weight: inherit;
                  width: 600px;
                  padding: 0;
                "
              >
                <center>
                  <h3 style="font-size: 22px; color: orange; margin-bottom: 0">
                    Get in touch
                  </h3>
                  <p style="margin: 10px 0">{{$Phone_two}}</p>
                  <p style="margin: 10px 0">{{$email}}</p>
                  <a href="{{$facebook}}"
                    ><img
                      src="https://www.pngkey.com/png/full/90-902640_facebook-logo-circle-black-transparent-logo-fb-vector.png"
                      width="30"
                      alt=""
                      style="
                        border: 0;
                        margin: 10px 5px;
                        padding: 2px;
                        border-radius: 50%;
                      "
                  /></a>
                  <a href="{{$Twitter}}"
                    ><img
                      src="https://www.seekpng.com/png/detail/84-842766_logo-twitter-png-noir-twitter-icon-vector-circle.png"
                      width="30"
                      alt=""
                      style="
                        border: 0;
                        margin: 10px 5px;
                        padding: 2px;
                        border-radius: 50%;
                      "
                  /></a>
                  <a href="{{$youtube}}"
                    ><img src="https://www.pngkey.com/png/detail/6-61720_transparent-youtube-circle-youtube-icon-black-and-white.png" alt="Transparent Youtube Circle - Youtube Icon Black And White@pngkey.com"
                      width="30"
                      alt=""
                      style="
                        border: 0;
                        margin: 10px 5px;
                        padding: 2px;
                        border-radius: 50%;
                      "
                  /></a>
                  <a href="{{$instagram}}"
                    ><img src="https://www.pngkey.com/png/detail/43-432946_download-instagram-icon-black-circle-clipart-computer-black.png" alt="Download Instagram Icon Black Circle Clipart Computer - Black Round Instagram Logo@pngkey.com"
                      width="30"
                      alt=""
                      style="
                        border: 0;
                        margin: 10px 5px;
                        padding: 2px;
                        border-radius: 50%;
                      "
                  /></a>
                </center>
              </td>
            </tr>
            <tr
              class="copyright-holder"
              style="
                border: none;
                border-collapse: inherit;
                border-spacing: 0;
                border-color: inherit;
                vertical-align: inherit;
                font-weight: inherit;
                width: 600px;
              "
            >
              <td
                style="
                  border: none;
                  border-collapse: inherit;
                  border-spacing: 0;
                  border-color: inherit;
                  vertical-align: inherit;
                  font-weight: inherit;
                  width: 600px;
                  padding: 0;
                  background-color: orange;
                  color: #fff;
                  padding: 15px;
                  font-size: 12px;
                "
              >
                <center>Copyrights © {{$powered_by}} All Right Reserved</center>
              </td>
            </tr>
          </table>
        </center>
      </body>
    </html>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>

{{-- @dd('THIS') --}}
