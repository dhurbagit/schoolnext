<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\About;
use App\Models\Client;
use App\Models\Counter;
use App\Models\Gallery;
use App\Models\NewsEvent;
use App\Models\Noticeboard;
use App\Models\Setting;
use App\Models\Slider;
use App\Models\Testimonial;
use App\Models\Video;

class HomeController extends Controller
{
    //
    
}
